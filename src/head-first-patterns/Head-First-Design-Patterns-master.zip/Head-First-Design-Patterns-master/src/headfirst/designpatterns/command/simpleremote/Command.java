package headfirst.designpatterns.command.simpleremote;

public interface Command {
	public void execute();
}
