package headfirst.designpatterns.factory.pizzaaf;

public class FreshClams implements Clams {

	public String toString() {
		return "Fresh Clams from Long Island Sound";
	}
}
